import streamlit as st
import pickle
import pandas as pd

# --- Configuration for a Professional Look ---
st.set_page_config(
    page_title="Premier Customer Churn Predictor", 
    layout="wide",  # Use 'wide' layout for more space
    initial_sidebar_state="collapsed"
)

# --- Load model and encoders ---
# Use st.cache_resource for heavy/global resources like models/encoders
@st.cache_resource
def load_resources():
    try:
        model = pickle.load(open("lgbm_model.pkl", "rb"))
        gender_le = pickle.load(open("gender_le.pkl", "rb"))
        payment_le = pickle.load(open("payment_le.pkl", "rb"))
        return model, gender_le, payment_le
    except FileNotFoundError:
        st.error("Error: Model or encoder files not found. Please ensure 'lgbm_model.pkl', 'gender_le.pkl', and 'payment_le.pkl' are in the directory.")
        return None, None, None

model, gender_le, payment_le = load_resources()

if model is None:
    st.stop() # Stop execution if files are missing

# --- Prediction Function ---
def predict_churn(data):
    # Apply encoders
    data['gender'] = gender_le.transform([data['gender']])[0]
    data['payment'] = payment_le.transform([data['payment']])[0]
    
    # Create DataFrame for prediction
    feature_cols = [
        'customer_age', 'total_spent', 'avg_quantity', 
        'num_categories', 'total_returns', 'num_orders', 
        'recency_days', 'tenure_days', 'gender', 'payment'
    ]
    
    # Ensure correct order and type
    input_df = pd.DataFrame([data], columns=feature_cols)
    
    # Predict probability (for a more professional output)
    churn_prob = model.predict_proba(input_df)[:, 1][0]
    return churn_prob

# --- App Layout and Styling (Enhanced Visuals) ---

# Custom CSS for enhanced styling, shadows, and fonts
st.markdown("""
<style>
    .reportview-container {
        background: #f0f2f6; /* Light background */
    }
    .stApp {
        background-color: #f0f2f6;
    }
    .stTitle {
        font-size: 3em;
        color: #1f77b4; /* Primary color */
        text-align: center;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
    }
    .stHeader {
        background-color: #ffffff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
        margin-bottom: 20px;
    }
    /* Style for the input form container */
    div[data-testid="stForm"] {
        background-color: #ffffff;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1); /* Deeper shadow for professional look */
    }
    .stTextInput>div>div>input, .stNumberInput>div>div>input, .stSelectbox>div>div>select {
        border-radius: 8px;
        border: 1px solid #ced4da;
        padding: 10px;
    }
    .stButton>button {
        background-color: #28a745; /* Success green for button */
        color: white;
        font-weight: bold;
        padding: 10px 20px;
        border-radius: 10px;
        transition: all 0.3s ease;
    }
    .stButton>button:hover {
        background-color: #1e7e34;
        transform: translateY(-2px); /* Simple hover animation */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
</style>
""", unsafe_allow_html=True)


# --- Header Section ---
st.markdown("<h1 class='stTitle'> Customer Churn Prediction System</h1>", unsafe_allow_html=True)
st.info("🎯 Utilize advanced machine learning to assess the likelihood of a customer churning. **Requires all fields to be completed.**")
st.markdown('</div>', unsafe_allow_html=True)

# --- Input Form using Columns for better layout ---
st.header("⚙️ Customer Profile Data Entry")

with st.form("prediction_form", clear_on_submit=False):
    # Group inputs into columns
    col1, col2, col3 = st.columns(3)

    # Column 1: Identification & Demographics
    with col1:
        st.subheader("👤 Identity & Age")
        gender = st.selectbox("Gender", gender_le.classes_)
        customer_age = st.slider("Customer Age", min_value=18, max_value=100, value=30, help="Customer's current age.")
        recency_days = st.number_input("Days Since Last Purchase (Recency)", min_value=0, value=30, format="%d", help="Fewer days is better.")
    
    # Column 2: Spending & Activity
    with col2:
        st.subheader("💰 Financial Metrics")
        total_spent = st.number_input("Total Spent ($)", min_value=0.0, value=1000.0, format="%.2f", help="Total historical spending by the customer.")
        avg_quantity = st.number_input("Avg Quantity per Order", min_value=0.0, value=2.0, format="%.2f", help="Average number of items in each order.")
        num_categories = st.number_input("Unique Categories Purchased", min_value=1, value=3, format="%d", help="Diversity of products bought.")

    # Column 3: Order & Recency
    with col3:
        st.subheader("📈 Engagement Data")
        total_returns = st.number_input("Total Returns", min_value=0, value=0, format="%d", help="Total number of returned items/orders.")
        payment = st.selectbox("Preferred Payment Method", payment_le.classes_)
        num_orders = st.number_input("Total Number of Orders", min_value=1, value=5, format="%d", help="Total count of purchases.")
    
    # Separator
    st.markdown("---")
    
    tenure_days = st.number_input("Customer Tenure (days)", min_value=0, value=365, format="%d", help="Duration since the customer first registered.")
    
    st.markdown("---")
    
    # Submission Button (Centered)
    submitted = st.form_submit_button("🚀 Execute Churn Prediction")

# --- When form is submitted ---
if submitted:
    # Encode categorical values
    gender_encoded = gender_le.transform([gender])[0]
    payment_encoded = payment_le.transform([payment])[0]

    # Create input DataFrame
    input_data = pd.DataFrame({
        "Gender": [gender_encoded],
        "Customer Age": [customer_age],
        "total_spent": [total_spent],
        "avg_quantity": [avg_quantity],
        "num_categories": [num_categories],
        "total_returns": [total_returns],
        "most_common_payment": [payment_encoded],
        "num_orders": [num_orders],
        "recency_days": [recency_days],
        "tenure_days": [tenure_days]
    })

    # Predict
    churn_prob = model.predict_proba(input_data)[0][1]
    churn_risk = "🔴 High Risk" if churn_prob > 0.5 else "🟢 Low Risk"

    # --- Display results ---
    st.subheader("Prediction Result")
    st.metric("Churn Probability", f"{churn_prob:.2%}")
    st.write(f"**Churn Risk Level:** {churn_risk}")
