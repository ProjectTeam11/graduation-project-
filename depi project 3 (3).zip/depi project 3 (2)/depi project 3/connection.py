import pyodbc

conn = pyodbc.connect(
    "Driver={ODBC Driver 17 for SQL Server};"
    "Server=LAPTOP-SL1JQ9D6\SQLEXPRESS01;"         # or YOUR-SERVER-NAME
    "Database=Depi_project;"    
    "Trusted_Connection=yes;"  
)

cursor = conn.cursor()

cursor.execute("SELECT TOP 10 * FROM Customer")
# rows = cursor.fetchall()

# for row in rows:
#     print(row)

print(cursor.fetchall())

conn.close()
